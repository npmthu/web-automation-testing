# Seminar submission — test scripts & metrics

## Structure

```
config/
  playwright.config.root.js          root playwright.config.js (chromium/firefox/webkit, tests/)
  playwright.config.frontend-web.js  frontend-web/playwright.config.js (chromium, tests/, dev server)
tests/
  login/
    fr02-login-smoke.spec.js               login-example.spec.js
    fr02-login-core-and-lockout.spec.js    fr02-login-A.spec.js
    fr02-login-reset-and-edge-cases.spec.js fr02-login-B.spec.js
    fr02-login-security-and-escalation.spec.js fr02-login-C.spec.js
  cart/
    fr07-add-to-cart.spec.js               frontend-web/tests/add-to-cart.spec.js
    fr07-add-to-cart-throttled.spec.js     frontend-web/tests/add-to-cart.throttled.spec.js
  checkout/
    fr08-checkout.spec.js                  frontend-web/tests/checkout.spec.js
  flakiness/
    fr02-fr08-flakiness-sweep.spec.js      frontend-web/tests/flakiness-sweep.spec.js
  ai-track/                                frontend-web/tests/ai-track/ (copied as-is, names unchanged —
                                            scenario.md / prompt-log.md / assertions-diff.md / both
                                            add-to-cart.ai-*.spec.js / flakiness-network.spec.js
                                            cross-reference each other by exact filename)
  helpers/
    network-throttle.js                    frontend-web/tests/helpers/network-throttle.js
  security/
    role-escalation-poc.js                 backend/test_profile.js (JWT-forgery / role-escalation PoC
                                            behind TC-18a/b in fr02-login-security-and-escalation.spec.js)
  boilerplate/
    playwright-starter.spec.js             tests/example.spec.js (generic Playwright scaffold, not FR-specific)
metrics/
  flakiness-primary-fr02-fr07-fr08.md      metrics/flakiness.md (root, canonical — WAT-18 FR-07 hand-written
                                            vs AI-audited + WAT-13 FR-02/FR-08 sweep)
  flakiness-supplement-fr07-concurrency.md frontend-web/metrics/flakiness.md (supplementary — WAT-13 FR-07
                                            deep-dive under concurrent load)
```

## Notes

- Only two import paths needed fixing due to the new folder depth:
  `fr02-fr08-flakiness-sweep.spec.js` now imports
  `../helpers/network-throttle.js` (was `./helpers/...` one level up in the
  original layout). `ai-track/flakiness-network.spec.js` needed no change —
  same relative depth as before.
- File bodies (headers, WAT ticket references, deviation notes) are kept
  verbatim from the originals. Cross-references inside those bodies (e.g. a
  comment mentioning `metrics/flakiness.md` or `add-to-cart.spec.js`) still
  point at the _original_ repo paths, not the renamed copies here — use the
  mapping table above to translate.
